#!/bin/bash

# Claude Linux Client Installer
# This script installs the Claude desktop client for Linux

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Starting Claude Linux Client installation...${NC}"

# Check and install npm if needed
check_and_install_npm() {
  echo "Checking if npm is installed..."
  
  if ! command -v npm &> /dev/null; then
    echo -e "${YELLOW}npm is not installed. Would you like to install it now? (y/n): ${NC}"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])+$ ]]; then
      echo "Installing npm..."
      sudo apt install npm || {
        echo -e "${RED}Failed to install npm. Please install it manually.${NC}"
        exit 1
      }
      echo -e "${GREEN}npm installed successfully.${NC}"
    else
      echo -e "${RED}npm is required for installation. Exiting.${NC}"
      exit 1
    fi
  else
    echo -e "${GREEN}npm is already installed.${NC}"
  fi
}

# Check if nodejs and npm are installed
check_dependencies() {
  echo "Checking dependencies..."
  
  if ! command -v node &> /dev/null; then
    echo -e "${RED}Node.js is not installed. Please install nodejs (v14 or later).${NC}"
    echo "You can install Node.js by following instructions at: https://nodejs.org/en/download/"
    exit 1
  fi
  
  node_version=$(node -v | cut -d 'v' -f 2)
  required_version="14.0.0"
  
  if [ "$(printf '%s\n' "$required_version" "$node_version" | sort -V | head -n1)" != "$required_version" ]; then
    echo -e "${RED}Node.js version must be 14.0.0 or higher. Current version: $node_version${NC}"
    exit 1
  fi
  
  # npm check is now handled by check_and_install_npm function
  
  echo -e "${GREEN}All dependencies satisfied.${NC}"
}

# Create application directory
create_app_directory() {
  echo "Setting up application directory..."
  
  APP_DIR="$HOME/.claude-linux-client"
  
  if [ -d "$APP_DIR" ]; then
    echo "Application directory already exists at $APP_DIR"
    echo -n "Do you want to remove the existing installation? (y/n): "
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])+$ ]]; then
      echo "Removing existing installation..."
      rm -rf "$APP_DIR"
    else
      echo "Installation aborted."
      exit 0
    fi
  fi
  
  mkdir -p "$APP_DIR"
  
  echo -e "${GREEN}Application directory created at $APP_DIR${NC}"
}

# Copy files to application directory
copy_files() {
  echo "Copying application files..."
  
  # Get the directory of the current script
  SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
  
  # Copy all necessary files
  cp "$SCRIPT_DIR/main.js" "$APP_DIR/main.js"
  cp "$SCRIPT_DIR/preload.js" "$APP_DIR/preload.js"
  cp "$SCRIPT_DIR/package.json" "$APP_DIR/package.json"
  cp "$SCRIPT_DIR/package-lock.json" "$APP_DIR/package-lock.json"
  cp "$SCRIPT_DIR/start.sh" "$APP_DIR/start.sh"
  chmod +x "$APP_DIR/start.sh"
  
  # Copy the uninstaller
  cp "$SCRIPT_DIR/uninstall.sh" "$APP_DIR/uninstall.sh"
  chmod +x "$APP_DIR/uninstall.sh"
  
  # Create assets directory
  mkdir -p "$APP_DIR/assets"
  
  # Check if icon exists and copy it
  if [ -f "$SCRIPT_DIR/assets/icon.png" ]; then
    cp "$SCRIPT_DIR/assets/icon.png" "$APP_DIR/assets/icon.png"
    echo -e "${GREEN}Icon copied successfully.${NC}"
  else
    echo -e "${YELLOW}Warning: Icon file not found at $SCRIPT_DIR/assets/icon.png${NC}"
    echo -e "${YELLOW}Application will use system default icon.${NC}"
  fi
  
  echo -e "${GREEN}Files copied successfully.${NC}"
}

# Install dependencies
install_dependencies() {
  echo "Installing dependencies..."
  
  cd "$APP_DIR" || {
    echo -e "${RED}Failed to change to application directory.${NC}"
    exit 1
  }
  
  # Using --no-fund --no-audit --loglevel=error to suppress warnings
  npm install --no-fund --no-audit --loglevel=error || {
    echo -e "${RED}Failed to install dependencies.${NC}"
    exit 1
  }
  
  echo -e "${GREEN}Dependencies installed successfully.${NC}"
}

# Create desktop entry and shortcut
create_desktop_entry() {
  echo "Creating desktop entries..."
  
  # Application menu entry path
  APP_MENU_DIR="$HOME/.local/share/applications"
  DESKTOP_FILE="$APP_MENU_DIR/claude-linux-client.desktop"
  
  # Desktop shortcut path
  DESKTOP_DIR="$HOME/Desktop"
  DESKTOP_SHORTCUT="$DESKTOP_DIR/Claude.desktop"
  
  # Create the .desktop file content
  DESKTOP_CONTENT="[Desktop Entry]
Name=Claude
Comment=Claude AI desktop client
Exec=bash -c \"cd $APP_DIR && ./start.sh\"
Icon=$APP_DIR/assets/icon.png
Terminal=false
Type=Application
Categories=Development;
Keywords=claude;ai;chat;
"
  
  # Write content to application menu entry if directory exists
  if [ -d "$APP_MENU_DIR" ]; then
    echo "$DESKTOP_CONTENT" > "$DESKTOP_FILE"
    chmod +x "$DESKTOP_FILE"
    echo -e "${GREEN}Application menu entry created at $DESKTOP_FILE${NC}"
  else
    echo -e "${YELLOW}Application menu directory not found. Skipping menu entry creation.${NC}"
  fi
  
  # Write content to desktop shortcut if Desktop directory exists
  if [ -d "$DESKTOP_DIR" ]; then
    echo "$DESKTOP_CONTENT" > "$DESKTOP_SHORTCUT"
    chmod +x "$DESKTOP_SHORTCUT"
    echo -e "${GREEN}Desktop shortcut created at $DESKTOP_SHORTCUT${NC}"
  else
    echo -e "${YELLOW}Desktop directory not found. Skipping desktop shortcut creation.${NC}"
  fi
}

# Main installation process
main() {
  check_and_install_npm
  check_dependencies
  create_app_directory
  copy_files
  install_dependencies
  create_desktop_entry
  
  echo -e "${GREEN}Installation complete!${NC}"
  echo -e "You can start Claude Linux Client by:"
  
  if [ -d "$HOME/Desktop" ]; then
    echo -e "* Double-clicking the Claude icon on your Desktop"
  fi
  
  if [ -d "$HOME/.local/share/applications" ]; then
    echo -e "* Finding Claude in your application menu"
  fi
  
  echo -e "* Running this command: ${YELLOW}cd $APP_DIR && ./start.sh${NC}"
  echo -e "To uninstall, run: ${YELLOW}$APP_DIR/uninstall.sh${NC}"
}

# Run the main function
main
