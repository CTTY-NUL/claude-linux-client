// preload.js
const { contextBridge, ipcRenderer } = require('electron');

// Expose any APIs needed for the renderer process
contextBridge.exposeInMainWorld('electronAPI', {
  // Add session-related utilities
  copyToClipboard: (text) => {
    require('electron').clipboard.writeText(text);
  },
  checkSessionStatus: () => {
    return document.cookie.includes('authenticated') || 
           document.cookie.includes('session');
  }
});
