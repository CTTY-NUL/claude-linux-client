#!/bin/bash

# Claude Linux Client Uninstaller
# This script uninstalls the Claude desktop client for Linux

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Uninstalling Claude Linux Client...${NC}"

# Application directory
APP_DIR="$HOME/.claude-linux-client"

# Application menu entry
APP_MENU_ENTRY="$HOME/.local/share/applications/claude-linux-client.desktop"

# Desktop shortcut
DESKTOP_SHORTCUT="$HOME/Desktop/Claude.desktop"

# Confirm uninstallation
echo -n "Are you sure you want to uninstall Claude Linux Client? (y/n): "
read -r response
if [[ ! "$response" =~ ^([yY][eE][sS]|[yY])+$ ]]; then
  echo "Uninstallation cancelled."
  exit 0
fi

# Remove application menu entry if it exists
if [ -f "$APP_MENU_ENTRY" ]; then
  rm -f "$APP_MENU_ENTRY"
  echo -e "${GREEN}Removed application menu entry.${NC}"
fi

# Remove desktop shortcut if it exists
if [ -f "$DESKTOP_SHORTCUT" ]; then
  rm -f "$DESKTOP_SHORTCUT"
  echo -e "${GREEN}Removed desktop shortcut.${NC}"
fi

# Remove application directory if it exists
if [ -d "$APP_DIR" ]; then
  rm -rf "$APP_DIR"
  echo -e "${GREEN}Removed application files.${NC}"
fi

echo -e "${GREEN}Claude Linux Client has been successfully uninstalled.${NC}"