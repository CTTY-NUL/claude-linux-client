// main.js with GPU acceleration disabled
const { app, BrowserWindow, Menu, ipcMain, session } = require('electron');
const path = require('path');
const Store = require('electron-store');

// Disable GPU acceleration to prevent crashes on NVIDIA GPUs
app.disableHardwareAcceleration();
app.commandLine.appendSwitch('disable-gpu');
app.commandLine.appendSwitch('disable-gpu-compositing');
app.commandLine.appendSwitch('disable-gpu-rasterization');
app.commandLine.appendSwitch('disable-zero-copy');
app.commandLine.appendSwitch('ignore-gpu-blacklist');
app.commandLine.appendSwitch('disable-software-rasterizer');

// Add these with the other app.commandLine.appendSwitch calls
app.commandLine.appendSwitch('disable-gpu-vsync');
app.commandLine.appendSwitch('disable-accelerated-2d-canvas');

// Initialize storage for user preferences
const store = new Store();

let mainWindow;

// Create the main application window
function createWindow() {
  // Get saved window dimensions, or use defaults
  const windowState = store.get('windowState', {
    width: 1200,
    height: 800
  });

  mainWindow = new BrowserWindow({
    width: windowState.width,
    height: windowState.height,
    icon: path.join(__dirname, 'assets/icon.png'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      // Disable GPU features
      webgl: false,
      acceleratedCanvas: false,
//      offscreen: true
    }
  });

  // Load Claude's web interface
  mainWindow.loadURL('https://claude.ai');

  // Save window dimensions when closing
  mainWindow.on('close', () => {
    const { width, height } = mainWindow.getBounds();
    store.set('windowState', { width, height });
  });

  // Create application menu
  const menu = Menu.buildFromTemplate([
    {
      label: 'File',
      submenu: [
        { role: 'quit' }
      ]
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' },
        { role: 'delete' },
        { type: 'separator' },
        { role: 'selectAll' }
      ]
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forceReload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' }
      ]
    }
  ]);
  
  Menu.setApplicationMenu(menu);
}

// Set up session persistence to extend login duration
function setupSessionPersistence() {
  // Set longer cookie expiration
  session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
    const responseHeaders = details.responseHeaders || {};
    
    // Process Set-Cookie headers to extend session duration if possible
    if (responseHeaders['set-cookie']) {
      const cookies = responseHeaders['set-cookie'].map(cookie => {
        // If there's a short expiration, try to extend it
        if (cookie.includes('Max-Age=') || cookie.includes('Expires=')) {
          // Attempt to extend the cookie lifetime (90 days)
          return cookie.replace(/Max-Age=\d+/, 'Max-Age=7776000')
                       .replace(/Expires=[^;]+/, function(match) {
                         const newDate = new Date();
                         newDate.setDate(newDate.getDate() + 90);
                         return `Expires=${newDate.toUTCString()}`;
                       });
        }
        return cookie;
      });
      
      responseHeaders['set-cookie'] = cookies;
    }
    
    callback({ responseHeaders });
  });
  
  // Disable cache clearing on browser close
  session.defaultSession.allowNTLMCredentialsForDomains('*');
  
  // Store cookies and sessions persistently
  const cookiesPath = path.join(app.getPath('userData'), 'cookies');
  store.set('cookiesPath', cookiesPath);
  
  // Persist cookies and storage
  app.on('will-quit', () => {
    // Save session data explicitly if needed
    session.defaultSession.cookies.get({})
      .then((cookies) => {
        store.set('savedCookies', cookies);
      })
      .catch((error) => {
        console.error('Failed to save cookies', error);
      });
  });
  
  // Restore cookies on startup
  const savedCookies = store.get('savedCookies', []);
if (savedCookies.length > 0) {
  for (const cookie of savedCookies) {
    // Filter out any expired cookies
    const now = new Date().getTime() / 1000;
    if (!cookie.expirationDate || cookie.expirationDate > now) {
      // Fix url property and domain if needed
      if (cookie.domain) {
        // Ensure domain is properly formatted
        if (cookie.domain.startsWith('.')) {
          cookie.domain = cookie.domain.substring(1);
        }
        
        const prefix = cookie.secure ? 'https://' : 'http://';
        cookie.url = prefix + cookie.domain;
        
        // Only attempt to set cookies for valid domains
        if (cookie.domain.includes('.') && !cookie.domain.startsWith('192.168.') && 
            !cookie.domain.startsWith('127.0.0.1')) {
          session.defaultSession.cookies.set(cookie)
            .catch(error => console.error('Error restoring cookie:', error));
        }
      }
    }
  }
}
  
  // Handle expired sessions
  session.defaultSession.webRequest.onCompleted((details) => {
    if (details.statusCode === 401 || details.statusCode === 403) {
      // Detect login page and handle accordingly
      if (details.url.includes('login') || details.url.includes('auth')) {
        console.log('Session expired, user needs to login again');
        mainWindow.webContents.executeJavaScript(`
          console.log("Session expired, please log in again");
        `).catch(err => console.error(err));
      }
    }
  });
}

// Initialize app when ready
app.whenReady().then(() => {
  createWindow();
  setupSessionPersistence();
  
  app.on('render-process-gone', (event, webContents, details) => {
  console.log('Renderer process gone:', details.reason);
});

app.on('gpu-process-crashed', (event, killed) => {
  console.log('GPU process crashed or was killed');
});
  
  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

// Quit app when all windows are closed (except on macOS)
app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
});
